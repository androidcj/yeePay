package util;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class ConfigInfo {
	
	public static final String INIT_FIE =   "/init.properties";
	
	public static String getValue(String key){
		Properties prop = new Properties();
		String value = "";
		try {
//			File file = new  File(ConfigInfo.class.getClass());
//			if(file==null || !file.exists()  ){
//				file.createNewFile();
//				System.out.println("files===="+file.getAbsolutePath());
//			}
//			System.out.println();
			InputStream is = ConfigInfo.class.getResourceAsStream(INIT_FIE);
			
			prop.load(is);
			
			value = prop.getProperty(key);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return value;
	}
	
	
}
